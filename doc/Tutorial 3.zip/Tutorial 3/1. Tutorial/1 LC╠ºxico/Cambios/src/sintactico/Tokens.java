/**
 * @author Ra�l Izquierdo
 */

package sintactico;

public class Tokens {
	public static final int INT = 257;
	public static final int REAL = 258;

	public static final int CODE = 259;
	public static final int DATA = 260;

	public static final int PRINT = 261;

	public static final int LITERALREAL = 262;
	static final int LITERALINT = 263;
	static final int IDENT = 264;
}
