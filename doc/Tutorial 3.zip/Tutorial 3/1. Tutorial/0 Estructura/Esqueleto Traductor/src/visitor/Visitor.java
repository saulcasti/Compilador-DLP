package visitor;

/**
 *  Esta clase se completar� en la fase de An�lisis Sint�ctico.
 */

public interface Visitor {
	// public Object visit(Programa node, Object param);
}
