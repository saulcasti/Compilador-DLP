package visitor;

/**
 * DefaultVisitor. Implementaci�n base del visitor para ser derivada por nuevos visitor.
 * 
 *  Esta clase se completar� en la fase de An�lisis Sint�ctico.
 */
public class DefaultVisitor implements Visitor {

	// public Object visit(Programa nodo, Object param) {
	// ...
	// }

}
