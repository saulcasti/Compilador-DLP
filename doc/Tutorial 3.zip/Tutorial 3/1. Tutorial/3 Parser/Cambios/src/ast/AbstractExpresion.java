/**
 * @generated VGen 1.3.2
 */

package ast;

public abstract class AbstractExpresion extends AbstractTraceable implements Expresion {

}

