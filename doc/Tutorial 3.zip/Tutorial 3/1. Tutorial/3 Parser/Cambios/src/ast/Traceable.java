package ast;

/**
 * @generated VGen 1.3.2
 */

public interface Traceable {
	Position getStart();
	Position getEnd();
}
