/**
 * @generated VGen 1.3.2
 */

package ast;

public interface Expresion extends AST {

}

